Self-contained LaTeX package for the SCR ptychography manuscript draft.

Build from this directory with:
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  pdflatex -interaction=nonstopmode -halt-on-error main.tex

Contents:
  main.tex
  main.pdf
  figures/cdi_synthetic_line_pattern_scr_vs_fno.png
